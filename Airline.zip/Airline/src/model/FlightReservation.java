/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author zhiqingsu
 */
public class FlightReservation {
    int price;
    String id;
    String flightClass;
    String state; // purchased/canceled/refund/confirmed
    String company;
    String seat;
    Route route;
    Customer passenger;   
    Date date;

    public FlightReservation(Route route, String id,int price, Customer passenger, String flightClass, String seat, String company, Date date) {
        this.id = id;
        this.route = route;
        this.price = price;
        this.seat = seat;
        this.passenger = passenger;
        this.flightClass = flightClass;
        this.company = company;
        this.date = date;
        state = "purchased";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    
    

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    
    
    public Route getRoute() {
        return route;
    }

    public int getPrice() {
        return price;
    }

    public Customer getPassenger() {
        return passenger;
    }

    public String getFlightClass() {
        return flightClass;
    }



    public String getCompany() {
        return company;
    }

    public Date getDate() {
        return date;
    }

    
    public void updateDB(){
        try{
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinedb1", "root", "Airline3306");
            String query = "ON DUPLICATE KEY UPDATE flightreservation SET passengername = '" + passenger.name + "' ,passport = '" + passenger.passport + "' ,date = '" + date + "' ,company = '" + company + "' ,route = '" + route.routeName + "' ,class = '" + flightClass + "' ,price = '" + price + "' ,seat = '" + seat +"' ,reservationid = '" + id +"' WHERE reservationid = " + id;
            Statement add = (Statement) con.createStatement();
            add.executeUpdate(query);
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
}
